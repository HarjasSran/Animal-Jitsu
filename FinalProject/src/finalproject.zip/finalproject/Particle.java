/*
Cant do yet, need to wait for images
 */
package finalproject;

import java.awt.Image;

/**
 *
 * @author harja
 */
public class Particle extends GameObject {
    Image element;
    
    //public Particle(){
    //public Particle(image element, boolean direction)[    
    
    //setElement(Image element)
    
    //getElement()
    
    //clone()
    
    //toString()
}
